package university;

import facilities.Facility;
import facilities.buildings.Building;
import facilities.buildings.Hall;
import facilities.buildings.Lab;
import facilities.buildings.Theatre;

public class University {
  float budget;
  Estate estate;
  int reputation;
  public University(int funding) {
    budget = funding;
  }

  public int getReputation() {
    return reputation;
  }

  public float getBudget() {
    return budget;
  }

  public Facility build(String type, String name) {
    estate = new Estate();
    Facility j = estate.addFacility(type, name);
    if (j instanceof Hall) {
      int hallBase = ((Hall) j).getBaseBuildingCost();
      budget -= hallBase;
      reputation += 100;
      return j;
    } else if(j instanceof Lab) {
      int labBase = ((Lab) j).getBaseBuildingCost();
      budget -= labBase;
      reputation += 100;
      return j;
    } else if(j instanceof Theatre) {
      int theatreBase = ((Theatre) j).getBaseBuildingCost();
      budget -= theatreBase;
      reputation += 100;
      return j;
    }
    return null;
  }

  public void upgrade(Building building) throws Exception {
    try {
      System.out.println(building instanceof University);
      if(building instanceof University) {
        if (building instanceof Hall) {
          if (building.getLevel() != ((Hall) building).getMaxLevel()) {
            int cost = building.getUpgradeCost();
            building.increaseLevel();
            budget -= cost;
            reputation += 50;
          } else {
            throw new Exception("Hall is max level and can't be upgraded further");
          }
        } else if (building instanceof Lab) {
          if (building.getLevel() != ((Lab) building).getMaxLevel() && building instanceof University) {
            int cost = building.getUpgradeCost();
            building.increaseLevel();
            budget -= cost;
            reputation += 50;
          } else {
            throw new Exception("Lab is max level and can't be upgraded further");
          }
        } else if (building instanceof Theatre) {
          if (building.getLevel() != ((Theatre) building).getMaxLevel()
              && building instanceof University) {
            int cost = building.getUpgradeCost();
            building.increaseLevel();
            budget -= cost;
            reputation += 50;
          } else {
            throw new Exception("Theatre is max level and can't be upgraded further");
          }
        }
      } else {
        throw new Exception("Building is not part of the University");
      }
    } catch (Exception e) {
      System.out.println(e);
      }
  }

  public static void main(String[] args) throws Exception {
    University uni = new University(10000);
//    Hall hall = new Hall("John");
    Facility j = uni.build("Hall", "John");
    if(j instanceof Hall) { //How to check if building is a part of University
      System.out.println(((Hall) j).getLevel());
      uni.upgrade((Building) j);
      System.out.println(uni.getBudget());
      System.out.println(((Hall) j).getLevel());
    }



  }
}
