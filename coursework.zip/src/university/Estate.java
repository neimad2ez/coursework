package university;

import facilities.Facility;
import facilities.buildings.Hall;
import facilities.buildings.Lab;
import facilities.buildings.Theatre;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Estate {


  ArrayList<Facility> facilities;
  public Estate() {
    this.facilities = new ArrayList<Facility>();
  }

  public Facility[] getFacilities() {
    Facility[] facility1 = new Facility[facilities.size()];
    return facilities.toArray(facility1);
  }

  public Facility addFacility(String type, String name) {
    if(type == "Hall") {
      Hall hall1 = new Hall(name);
      facilities.add(hall1);
      return hall1;
    } else if(type == "Lab") {
      Lab lab1 = new Lab(name);
      facilities.add(lab1);
      return lab1;
    } else if(type == "Theatre") {
      Theatre theatre1 = new Theatre(name);
      facilities.add(theatre1);
      return theatre1;
    } else {
      return null;
    }
  }

  public float getMaintenanceCost() {
    int hallCapacity = 0;
    int labCapacity = 0;
    int theatreCapacity = 0;
    for(Facility f: facilities) {
      if(f instanceof Hall) {
        hallCapacity = ((Hall) f).getCapacity();
      } else if(f instanceof Lab) {
        labCapacity = ((Lab) f).getCapacity();
      } else if(f instanceof Theatre) {
        theatreCapacity = ((Theatre) f).getCapacity();
      }
    }
    float maintenanceCost = theatreCapacity + labCapacity + hallCapacity;
    maintenanceCost = (float) (maintenanceCost * 0.1);
    return maintenanceCost;
  }

  public int getNumberOfStudents() {
    int hallCapacity = 0;
    int labCapacity = 0;
    int theatreCapacity = 0;
    for(Facility f: facilities) {
      if(f instanceof Hall) {
        hallCapacity = ((Hall) f).getCapacity();
      } else if(f instanceof Lab) {
        labCapacity = ((Lab) f).getCapacity();
      } else if(f instanceof Theatre) {
        theatreCapacity = ((Theatre) f).getCapacity();
      }
    }
    int numOfStudents = Math.min(hallCapacity, Math.min(labCapacity, theatreCapacity));
    return numOfStudents;
  }
  public static void main(String[] args) {
    Estate estate1 = new Estate();
    Facility h = estate1.addFacility("Hall", "hi");
    System.out.println(estate1.getMaintenanceCost());
    if(h instanceof Hall) {
      ((Hall) h).increaseLevel();
      System.out.println(((Hall) h).getCapacity());
    }
    System.out.println(estate1.getMaintenanceCost());
  }

}
