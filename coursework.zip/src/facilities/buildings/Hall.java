package facilities.buildings;

import facilities.Facility;

public class Hall extends Facility implements Building{
    int level = 1;
    int baseBuildingCost = 100;
    int maxLevel = 4;
    int baseCapacity = 6;
    public Hall(String name) {
        super(name);
    }

    public int getLevel() {
        return level;
    }

    public int getBaseBuildingCost() {
        return baseBuildingCost;
    }

    public int getBaseCapacity() {
        return baseCapacity;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public void increaseLevel() {
        if(level != maxLevel) {
            level += 1;
        }
    }

    public int getUpgradeCost() {
        if(level == maxLevel) {
            return -1;
        } else {
            int upgrade = (baseBuildingCost * (level + 1));
            return upgrade;
        }
    }

    public int getCapacity() {
        int x = (int) Math.pow(2, level-1);
        int capacity = baseCapacity * x;
        return capacity;
    }

    public static void main(String[] args) {
        Hall hall = new Hall("Johnny");
        System.out.println(hall.getUpgradeCost());
    }
}
