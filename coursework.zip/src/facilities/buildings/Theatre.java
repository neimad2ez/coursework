package facilities.buildings;

import facilities.Facility;

public class Theatre extends Facility implements Building{
    int level = 1;
    int baseBuildingCost = 200;
    int maxLevel = 6;
    int baseCapacity = 10;
    public Theatre(String name) {
        super(name);
    }

    public int getLevel() {
        return level;
    }

    public void increaseLevel() {
        if(level != maxLevel) {
            level += 1;
        }
    }

    public int getBaseCapacity() {
        return baseCapacity;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public int getBaseBuildingCost() {
        return baseBuildingCost;
    }

    public int getUpgradeCost() {
        if(level == maxLevel) {
            return -1;
        } else {
            int upgrade = (baseBuildingCost * (level + 1));
            return upgrade;
        }
    }

    public int getCapacity() {
        int x = (int) Math.pow(2, level-1);
        int capacity = baseCapacity * x;
        return capacity;
    }

}
