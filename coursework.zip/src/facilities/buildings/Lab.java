package facilities.buildings;

import facilities.Facility;

public class Lab extends Facility implements Building{
    int level = 1;
    int baseBuildingCost = 300;
    int maxLevel = 5;
    int baseCapacity = 5;
    public Lab(String name) {
        super(name);
    }

    public int getLevel() {
        return level;
    }

    public void increaseLevel() {
        if(level != maxLevel) {
            level += 1;
        }
    }

    public int getBaseCapacity() {
        return baseCapacity;
    }

    public int getBaseBuildingCost() {
        return baseBuildingCost;
    }

    public int getUpgradeCost() {
        if(level == maxLevel) {
            return -1;
        } else {
            int upgrade = (baseBuildingCost * (level + 1));
            return upgrade;
        }
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public int getCapacity() {
        int x = (int) Math.pow(2, level-1);
        int capacity = baseCapacity * x;
        return capacity;
    }
}
